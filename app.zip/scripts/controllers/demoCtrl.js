(function () {
  'use strict';

  angular.module('myApp.controllers')
    .controller('DemoCtrl', ['$scope', function($scope){
      $scope.svgpath = "svg/SVGTEST.svg";

      $scope.siteplans = [
        {name: "kontek_level_1.svg"},
        {name: "kontek_level_1.svg"},
        {name: "SVGTEST.svg"},
        {name: "kontek_level_1.svg"},
        {name: "kontek_level_1.svg"},
        {name: "SVGTEST.svg"},
        {name: "kontek_level_1.svg"},
        {name: "kontek_level_1.svg"},
        {name: "SVGTEST.svg"},
      ];
      $scope.d3OnClick = function(item){
        alert(item.name);
      };
    }]);

}());
