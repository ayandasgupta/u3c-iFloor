(function() {
    'use strict';

    angular.module('myApp.directives')
        .directive('customMap', ['d3', function(d3) {
            return {
                restrict: 'EA',
                scope: {
                    data: "@",
                    label: "@",
                    onClick: "&"
                },
                link: function(scope, iElement, iAttrs) {

                    // on window resize, re-render d3 canvas
                    window.onresize = function() {
                        return scope.$apply();
                    };
                    scope.$watch(function() {
                        return angular.element(window)[0].innerWidth;
                    }, function() {
                        return scope.render2(scope.data);
                    });

                    // watch for data changes and re-render
                    scope.$watch('data', function(newVals, oldVals) {
                        return scope.render2(newVals);
                    }, true);

                    // define render function
                    scope.render2 = function(data) {


                        d3.xml(data, "image/svg+xml", function(error, xml) {
                            if (error) throw error;

                            d3.select(iElement)[0][0].html("");
                            d3.select(iElement)[0][0].append(xml.documentElement);


                            d3.select(iElement[0]).selectAll("*").style("pointer-events", "visible").
                            on('mouseover', function(d, i) {
                                    console.log(d);
                                    console.log("d");
                                    console.log(i);
                                    this.style.stroke = "blue";
                                    this.style["stroke-width"] = 3;
                                })
                                .on('mouseout', function(d, i) {
                                    console.log(d);
                                    console.log("d");
                                    console.log(i);
                                    this.style.stroke = "black";
                                    this.style["stroke-width"] = 0.2;
                                })
                                .on('click', function(d, i) {
                                    console.log("d");
                                    console.log(i);
                                    console.log(this);
                                    if (this.id)
                                        alert("Area ID:" + this.id);


                                });


                        });




                    };
                }
            };
        }]);

}());