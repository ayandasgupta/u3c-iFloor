(function () {
  'use strict';

  angular.module('myApp.directives')
    .directive('svgList', ['d3', function(d3) {
      return {
        restrict: 'EA',
        scope: {
          data:"=",
          onClick: "&"
        },
        transclude: false,
        templateUrl : 'templates/svglist.html',
        link: function(scope, iElement, iAttrs) { 
            
            
                
          }
        }
      
    }]);

}());
